typedef int sortType;  

void quick_sort(sortType* list, int n, int N); 
#include "quick_sort.h"

void quick_sort_parallel(sortType* list, int n, int N, int n_el_processors[], int nthreads); 
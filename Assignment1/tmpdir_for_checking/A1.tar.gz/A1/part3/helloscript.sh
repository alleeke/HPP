echo Hej hej
echo Hallå hallå
